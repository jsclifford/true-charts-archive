Roadmap
=======

The cert-manager project roadmap has moved to the [cert-manager/community repo](https://github.com/cert-manager/community/blob/main/ROADMAP.md).
