# Project Governance

Please refer to the [cert-manager organisation governance file](https://github.com/cert-manager/community/blob/main/GOVERNANCE.md).
