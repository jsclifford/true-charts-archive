# README

A module for various Go static checks.
