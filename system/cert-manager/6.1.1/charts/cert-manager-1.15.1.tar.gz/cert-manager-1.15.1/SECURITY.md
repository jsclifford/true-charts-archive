# Security

Please refer to the [cert-manager organisation security document](https://github.com/cert-manager/community/blob/main/SECURITY.md).
