# Project Logo

Files for the cert-manager logo.

Note that the cert-manager logos in this repo are referred to in other README files in the cert-manager org;
if you change locations or names, you'll need to update several other repos too!

The logo was originally created by [Zoe Paterson](https://www.zoepatersonmedia.com/).

## Licensing

Please see the [LICENSE](./LICENSE) file for information on using the logo.
